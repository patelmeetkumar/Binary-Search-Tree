Name: Meetkumar Patel
CS 2400 Fall 2018 Java Project 3

The zip file contains the following interfaces:

StackInterface
Tree Interface
BinaryNodeInterface
BinaryTreeInterface
SearchTreeInterface

The zip file containes the following classes:

LinkedStack
BinaryNode
BinaryTree
BST
BSTTest

There are also classes that are written inside another
such as: InorderIterator, ReturnObject, and Node.

Note: Generic data type is used for the project.
BSTTest is the main class. Run that class to test
the project. I have tested the program and it runs
perfectly, without any errors, both locally and on
the internet. 

Thank you.